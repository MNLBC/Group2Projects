1. RUN project.sql in SQLDEV
2. EDIT tables to add trigger for sequence
3. RUN productdata.sql in SQLDEV
4. RUN insert.sql in SQLDEV

username: GROUP2
password: GROUP2