package com.oocl.mnlbc.proxy3;

public interface BookFacade {

	public void addBook();
}
