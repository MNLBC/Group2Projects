package com.oocl.mnlbc.proxy2;

public interface BookFacade {
	
	public void addBook();
}
